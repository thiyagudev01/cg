import { Component, OnInit } from '@angular/core';
import { FormBuilder,Validators } from '@angular/forms';
import { AuthenticationService} from '../auth/authentication.service';
import {Router} from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  login : any;
  submitted : boolean = false;
  constructor(private lg:FormBuilder,private au:AuthenticationService,private route:Router) { }

  ngOnInit() {
    this.login = this.lg.group({
      emailu:['',[Validators.required,Validators.email]],
      password:['',Validators.required]
    });
  }

  ngOnSubmit()
  {
    this.submitted = true;
    if(this.login.invalid)
    {
        return true
    }

    this.au.userLogin(this.login.value).subscribe(res=>{
        if(res)
        {
            this.route.navigate(['/dashboard'])
        }
        else
        {
            alert("User Does not exist");
        }
    });
  }

}
