import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { HomeComponent } from './home/home.component';
import { NotfoundComponent } from './notfound/notfound.component'
import {LogoutComponent} from './logout/logout.component';
import {AuthGuardService} from './guards/auth-guard.service';
const routes: Routes = [
  {
    path:'login',component:LoginComponent
  },
  {
    path:'signup',component:RegisterComponent
  },
  {
    path:'home',component:HomeComponent
  },
  {
    path:'',redirectTo:'/home',pathMatch:'full'
  },
  {
    path:'dashboard',component:DashboardComponent,canActivate:[AuthGuardService]
  },
  {
    path:'logout',component:LogoutComponent
  },
  {
    path:'**',component:NotfoundComponent
  }
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
