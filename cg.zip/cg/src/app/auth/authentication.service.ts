import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs'
import {map} from 'rxjs/operators'
@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  baseUrl:string = "http://localhost/cg/index.php/cg/login";

  constructor(private http:HttpClient) { }

  userLogin(data):Observable<any>
  {
      return this.http.post(this.baseUrl,data).pipe(map(res=>{
           if(res['data'] != 'nodata')
           {
              localStorage.setItem('id',res['data'].id);
              return true;
           }
           else{
             return false;
           }
          
      }));
  }
  isLoggedIn()
  {
    if(localStorage.getItem('id'))
    {
      return true;
    }
    else
    {
      return false;
    }
  }
}
