import { Component, OnInit } from '@angular/core';
import {FormBuilder, Validators,FormArray,FormControl} from '@angular/forms';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  formData: any;
  musicPreferences : any;
  constructor(private fb:FormBuilder) { }

  ngOnInit() {
    this.musicPreferences = [
      { id: 1, genre: 'Pop' },
      { id: 2, genre: 'Rock' },
      { id: 3, genre: 'Techno' },
      { id: 4, genre: 'Hiphop' }
    ];
    const formControls = this.musicPreferences.map(control => new FormControl(false));
    console.log(formControls);
    this.formData = this.fb.group({
      username : ['',Validators.required],
      password : ['',Validators.required],
      email : ['',[Validators.required,Validators.email]],
      gender : ['',Validators.required],
      musicPreferences: new FormArray(formControls),
      profile : ['',Validators.required],
    });
  }
  
  onRegister()
  {
    console.log(this.formData); 
    const selectedPreferences = this.formData.value.musicPreferences
    .map((checked, index) => checked ? this.musicPreferences[index].genre : null)
    .filter(value => value !== null);
    console.log(selectedPreferences.toString()); 
  }
}
