import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {

  user : any;
  check : boolean;
  constructor() { }

  ngOnInit() {
      this.user = localStorage.getItem('id');
      if(this.user)
      {
        this.check = true;
      }
      else
      {
        this.check = false;
      }
  }

}
