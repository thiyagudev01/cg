import { Injectable } from '@angular/core';
import {Router} from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthGuardService{

  constructor(private route:Router,private auth : AuthGuardService) { }

  canActivate(): Observable<boolean> | Promise<boolean> | boolean
  {
    if(localStorage.getItem('id'))
    {
      return true;
    }

    this.route.navigate(['/home']);
    return false;
  }
}
