<?php
class Cg_Model extends CI_Model
{

	function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	public function login($data)
	{
		$query = $this->db->query("Select * from users WHERE email='".$data->emailu."' AND password ='".$data->password."'");

		return $query->result_array();
	}

}

?>
